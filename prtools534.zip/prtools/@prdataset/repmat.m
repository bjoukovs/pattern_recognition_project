%REPMAT Dummy, to create error

function b = repmat(a,m,n)

error('Avoid REPMAT on datasets and datafiles: it will generate errors for 1-D feature spaces')

