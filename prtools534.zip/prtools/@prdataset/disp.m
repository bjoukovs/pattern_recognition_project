%DISP Display dataset
%
%	DISP(A)
%
% Display dataset A and its content

% $Id: disp.m,v 1.2 2006/03/08 22:06:58 duin Exp $

function disp(a)
			disp(a.data)

return
