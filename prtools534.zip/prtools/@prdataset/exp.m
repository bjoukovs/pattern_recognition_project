%EXP Dataset overload

% $Id: exp.m,v 1.2 2006/03/08 22:06:58 duin Exp $

function c = exp(a)
	
		c = setdata(a,exp(a.data));

return
