%HIST Datafile overload (error)

function hist(a)
	
		
	error('Histogram not implemented for datafiles')
	
return;
 