%REAL Datafile overload

function a = real(a)
	
	  
	a = a*filtm([],'real');
		
return
