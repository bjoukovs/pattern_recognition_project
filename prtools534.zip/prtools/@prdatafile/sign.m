%SIGN Datafile overload

function a = sign(a)
	
	  
	a = a*filtm([],'sign');
		
return
