%PRNEWLINE The platform dependent newline character
%
% c = prnewline
%
% In newer Matlab releases this function may be removed as NEWLINE has been
% built in. It is just here for backward compatibility.

function c = prnewline
	
	c = sprintf('\n');
	
return
